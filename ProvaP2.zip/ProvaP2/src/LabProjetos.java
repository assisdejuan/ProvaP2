import java.util.Stack;

public class LabProjetos extends SetorBase {

    private Stack<String> pilha = new Stack<>();

    public LabProjetos() {
        super("Laboratório de Projetos");
    }

    @Override
    public void registrarUsuario(String nome) {
        pilha.push(nome);
    }

    @Override
    public String atender() {
        return pilha.isEmpty() ? null : pilha.pop();  // último a entrar
    }

    @Override
    public void exibirEstado() {
        System.out.println("[" + nomeSetor + "] Pilha: " + pilha);
    }
}