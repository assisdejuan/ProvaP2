import java.util.ArrayList;
import java.util.List;

public class Historico {

    private List<String> atendidos = new ArrayList<>();

    public void registrar(String registro) {
        atendidos.add(registro);
    }

    public String ultimoAtendido() {
        return atendidos.isEmpty() ? null : atendidos.get(atendidos.size() - 1);
    }

    public void exibir() {
        System.out.println("Histórico Geral: " + atendidos);
    }
}
