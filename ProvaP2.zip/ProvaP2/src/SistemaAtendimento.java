public class SistemaAtendimento {

    public static void main(String[] args) {

        SetorAtendimento suporte = new CentralSuporte();
        SetorAtendimento lab = new LabProjetos();
        SetorAtendimento secretaria = new SecretariaAcademica();

        Historico historico = new Historico();

        suporte.registrarUsuario("Alice");
        suporte.registrarUsuario("Bruno");

        lab.registrarUsuario("Carla");
        lab.registrarUsuario("Daniel");

        secretaria.registrarUsuario("3");
        secretaria.registrarUsuario("1");
        secretaria.registrarUsuario("5");

        String a1 = suporte.atender();
        historico.registrar("[Suporte] " + a1);

        String a2 = lab.atender();
        historico.registrar("[Lab Projetos] " + a2);

        String a3 = secretaria.atender();
        historico.registrar("[Secretaria] " + a3);

        suporte.exibirEstado();
        lab.exibirEstado();
        secretaria.exibirEstado();

        System.out.println("Último usuário atendido: " + historico.ultimoAtendido());

        historico.exibir();
    }
}
