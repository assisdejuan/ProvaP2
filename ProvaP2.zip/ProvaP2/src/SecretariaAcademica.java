import java.util.PriorityQueue;

public class SecretariaAcademica extends SetorBase {

    private PriorityQueue<Integer> filaPrioridade = new PriorityQueue<>();

    public SecretariaAcademica() {
        super("Secretaria Acadêmica");
    }

    @Override
    public void registrarUsuario(String prioridadeStr) {
        int prioridade = Integer.parseInt(prioridadeStr);
        filaPrioridade.add(prioridade);
    }

    @Override
    public String atender() {
        Integer valor = filaPrioridade.poll(); // menor valor = maior prioridade
        return valor == null ? null : "Usuário de prioridade " + valor;
    }

    @Override
    public void exibirEstado() {
        System.out.println("[" + nomeSetor + "] Prioridades: " + filaPrioridade);
    }
}
