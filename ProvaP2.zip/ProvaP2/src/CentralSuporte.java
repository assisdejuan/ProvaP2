import java.util.LinkedList;
import java.util.Queue;
public class CentralSuporte extends SetorBase {

    private Queue<String> fila = new LinkedList<>();

    public CentralSuporte() {
        super("Central de Suporte");
    }

    @Override
    public void registrarUsuario(String nome) {
        fila.add(nome);
    }

    @Override
    public String atender() {
        return fila.poll();   // remove o primeiro
    }

    @Override
    public void exibirEstado() {
        System.out.println("[" + nomeSetor + "] Fila: " + fila);
    }
}
