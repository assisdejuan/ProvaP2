import java.util.*;

public abstract class SetorBase implements SetorAtendimento {

    protected String nomeSetor;

    public SetorBase(String nomeSetor) {
        this.nomeSetor = nomeSetor;
    }

    public String getNomeSetor() {
        return nomeSetor;
    }
}