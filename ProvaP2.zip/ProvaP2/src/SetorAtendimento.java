public interface SetorAtendimento {
    void registrarUsuario(String nome);
    String atender();
    void exibirEstado();
}



